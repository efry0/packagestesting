This tests making a package.
